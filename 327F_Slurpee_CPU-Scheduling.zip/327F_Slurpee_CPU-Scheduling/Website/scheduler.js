function finish(procs, info, timeline) {
  const rows = procs.map((p, i) => {
    const tat = info[i].ct - p.at;
    return { 
      name: p.name, 
      at: p.at, 
      bt: p.bt, 
      st: info[i].st, 
      ct: info[i].ct, 
      tat: tat, 
      wt: tat - p.bt 
    };
  });

  const avgWT = rows.reduce((s, r) => s + r.wt, 0) / rows.length;
  return { rows, timeline, avgWT };
}

function runInOrder(procs, order) {
  let t = 0;
  const info = [];
  const timeline = [];

  for (const i of order) {
    const p = procs[i];
    info[i] = { st: t, ct: t + p.bt };
    timeline.push({ name: p.name, start: t, end: t + p.bt });
    t += p.bt;
  }
  return finish(procs, info, timeline);
}

function fcfs(procs) {
  return runInOrder(procs, procs.map((_, i) => i));
}

function sjf(procs) {
  const order = procs.map((_, i) => i).sort((a, b) => {
    return procs[a].bt - procs[b].bt || a - b;
  });
  return runInOrder(procs, order);
}

function rr(procs, q) {
  const rem = procs.map(p => p.bt);
  const info = procs.map(() => ({ st: null, ct: null }));
  const timeline = [];
  const queue = procs.map((_, i) => i);
  let t = 0;

  while (queue.length > 0) {
    const i = queue.shift();
    
    if (info[i].st === null) {
      info[i].st = t;
    }

    const run = Math.min(q, rem[i]);
    const last = timeline[timeline.length - 1];

    if (last && last.name === procs[i].name && last.end === t) {
      last.end += run;
    } else {
      timeline.push({ name: procs[i].name, start: t, end: t + run });
    }

    t += run;
    rem[i] -= run;

    if (rem[i] > 0) {
      queue.push(i);
    } else {
      info[i].ct = t;
    }
  }

  return finish(procs, info, timeline);
}

const Scheduler = {
  fcfs,
  sjf,
  rr
};